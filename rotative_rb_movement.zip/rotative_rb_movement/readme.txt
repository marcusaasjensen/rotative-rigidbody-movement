Movement controls: Arrow keys / QWSD keys
Rotate the player: Scroll wheel

Copyrighted content under MIT license
Aas Jensen Marcus